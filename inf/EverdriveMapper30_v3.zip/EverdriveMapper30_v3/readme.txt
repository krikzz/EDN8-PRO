v3 update 2019-03-24:
- Flash write support
  - Adds ability to write PRG-ROM via the write-byte sequence.
  - Sector clear command is NOT supported, and neither is the behaviour of written bytes being ANDed with the original memory values.
  - Mapper30 software wanting to stay compatible with this Everdrive implementation needs to make sure to always write every byte it intends to read back.
  - Saving back to SD card won't work at this point in time, as it will require changes to the OS.
- Added Software ID command. 
  - Manufacturer ID is $ED and chip ID is $37
  - Having it different from the Flash ROM in the real mapper30 cartridge allows software to detect this, and possibly apply work-arounds.
- Added emulation of non-flashable config when battery bit is clear. Behavior changes as such:
  - Bankswitching register is mapped to entire $8000-$FFFF range
  - Write-byte-sequence and software ID command are not available
  - Bus conflicts are still NOT present, even for the non-flashable config

v2 update 2019-03-03:
- Switched interpretation of H/V bits when 4-screen mirroring set, to conform to clarified spec by Rainwarrior
- Converted source to use tabs instead of spaces
- Renamed .rbf file and added a pre-edited MAPROUT.BIN, for easier copy'n'paste installation to SD card

Mapper30 implementation for EverdriveN8, straight copy-n-paste from Krikzz's mapper2 example at http://krikzz.com/pub/support/everdrive-n8/development/fpga-mapper-sample.zip

Both variants of mapper30 are supported: 
1) The original mapper30, which can be hardwired for either vertical/horizontal mirroring, or mapper-controlled single-screen mirroring
2) The infinitelives variation, which replaces all of that with 4-screen mirroring (using the last 8kB of the 32kB CHR-RAM as nametable RAM)

And the interpretation of iNES header bits proposed in this thread is used to disambiguate between the two: 
http://wiki.nesdev.com/w/index.php/UNROM_512#Nametable_Configuration

Some existing mapper30 ROMs may not adhere to the proposed scheme, and would have to be edited.

michel_iwaniec@yahoo.com

Thanks to the following people:
* Krikzz, for creating the Everdrive N8 and sharing source examples
* Brad Smith (Rainwarrior), for his efforts in defining Mapper30, and his very useful Mapper30 test ROM
* Ellie Ryan, for helping out with testing the test ROM on a real Mapper30 cartridge
* Alex Orear, for his patience in testing on AVS. Someday we'll figure it out...