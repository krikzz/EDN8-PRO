project name: EDN8-M19-REV.FP2
pcb thickness 1.2mm
gold plated pads

layers order:
1. TOP
2. GND1
3. SIG
4. PWR
5. GND2
6. BOTTOM