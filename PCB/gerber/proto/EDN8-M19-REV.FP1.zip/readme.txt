project name: EDN8-M19-REV.FP1
pcb thickness 1.2mm
gold plated pads
layers order:
TOP
GND
PWR
BOTTOM